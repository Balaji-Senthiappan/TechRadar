/* eslint no-useless-constructor: "off" */

class BasePage {
  constructor() {}
}

module.exports = new BasePage()
