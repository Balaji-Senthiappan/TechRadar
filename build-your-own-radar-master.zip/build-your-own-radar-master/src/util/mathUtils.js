function toRadian(angleInDegrees) {
  return (Math.PI * angleInDegrees) / 180
}

module.exports = {
  toRadian,
}
